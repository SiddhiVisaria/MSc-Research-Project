Student ID: 210815867

1) Install and import all libraries.

2) Run the preprocessing.ipynb file first.

3) Run the LSTM.ipynb and CNN.ipynb files

4) Below is the accessible link for Google Drive, incase the files in this folder are not accessible.
https://drive.google.com/drive/folders/11CgaIimBwZgYzKN15veg4xwfOCHQf2mP?usp=sharing